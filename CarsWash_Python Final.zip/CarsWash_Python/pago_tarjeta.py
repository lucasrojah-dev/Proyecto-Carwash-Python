from pagable import Pagable


# 9. Interfaces: otra clase que implementa Pagable, demostrando que se pueden
# agregar nuevos medios de pago sin modificar el resto del sistema
class PagoTarjeta(Pagable):
    def __init__(self, numero_tarjeta: str):
        self._numero_tarjeta = numero_tarjeta  # 6. Encapsulamiento: atributo "privado"

    # 10. Polimorfismo: mismo método pagar(), comportamiento distinto al de PagoEfectivo
    def pagar(self, monto: float) -> bool:
        print("Procesando pago con tarjeta [" + self._numero_tarjeta + "] por: $" + str(monto))
        return True
