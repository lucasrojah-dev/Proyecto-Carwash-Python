from abc import ABC, abstractmethod


# 9. Interfaces: define un "contrato" que las clases de pago deben cumplir
# (en Python una interfaz se modela con una clase abstracta que solo tiene métodos abstractos)
class Pagable(ABC):
    # Método abstracto sin implementación; cada clase que herede de Pagable debe definirlo
    @abstractmethod
    def pagar(self, monto: float) -> bool:  # bool (éxito/fracaso) y float (monto)
        pass
