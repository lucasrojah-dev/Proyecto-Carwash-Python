from enum import Enum


# 2. Tipo de dato enumerado: limita los estados posibles a un conjunto fijo y conocido
# Ciclo de vida del auto: SIN_SERVICIO -> EN_ESPERA -> EN_PROCESO -> FINALIZADO
class EstadoServicio(Enum):
    SIN_SERVICIO = "Registrado, sin servicio"
    EN_ESPERA = "En espera"
    EN_PROCESO = "En proceso de lavado"
    FINALIZADO = "Finalizado"
