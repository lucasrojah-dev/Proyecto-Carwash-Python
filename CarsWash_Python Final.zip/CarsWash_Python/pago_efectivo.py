from pagable import Pagable


# 9. Interfaces: PagoEfectivo IMPLEMENTA la interfaz Pagable
class PagoEfectivo(Pagable):
    # 10. Polimorfismo: esta clase define su propia versión de pagar()
    def pagar(self, monto: float) -> bool:
        print("Procesando pago en efectivo por: $" + str(monto))  # "+" concatena texto
        return True  # 2. Tipo de dato bool
