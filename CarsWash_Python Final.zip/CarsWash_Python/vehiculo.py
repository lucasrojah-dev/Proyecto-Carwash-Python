from estado_servicio import EstadoServicio
from servicio import Servicio


# 5. Clases y abstracción: se representa lo esencial de un vehículo (patente, marca, modelo)
#    y ahora también el ESTADO de su servicio de lavado
# 7. Herencia: esta es la clase BASE de la que heredarán Auto, Camioneta, etc.
class Vehiculo:
    # Constructor: método especial que inicializa el objeto al crearlo
    def __init__(self, patente: str, marca: str, modelo: str):
        # 6. Encapsulamiento: atributos "privados" (por convención se usa _ al inicio)
        self._patente = patente  # 2. Tipo de dato str
        self._marca = marca      # 2. Tipo de dato str
        self._modelo = modelo    # 2. Tipo de dato str
        # --- Estado del servicio: pertenece al AUTO ---
        self._estado = EstadoServicio.SIN_SERVICIO
        self._servicio = None          # Servicio contratado (se asigna después de elegir y pagar)
        self._minutos_restantes = 0    # 2. Tipo de dato int

    # 6. Encapsulamiento: properties (equivalente a getters/setters de Java)
    @property
    def patente(self) -> str:
        return self._patente

    @patente.setter
    def patente(self, patente: str):
        self._patente = patente

    @property
    def marca(self) -> str:
        return self._marca

    @property
    def modelo(self) -> str:
        return self._modelo

    @property
    def estado(self) -> EstadoServicio:
        return self._estado

    @property
    def servicio(self):
        return self._servicio

    @property
    def minutos_restantes(self) -> int:
        return self._minutos_restantes

    # 4. Métodos: cada uno cambia el estado del auto
    def puede_contratar_servicio(self) -> bool:
        # Un auto puede contratar un servicio si no tiene uno activo (en espera o en proceso)
        return self._estado in (EstadoServicio.SIN_SERVICIO, EstadoServicio.FINALIZADO)

    def asignar_servicio(self, servicio: Servicio):
        self._servicio = servicio
        self._minutos_restantes = servicio.duracion_minutos
        self._estado = EstadoServicio.EN_ESPERA

    def iniciar_lavado(self):
        self._estado = EstadoServicio.EN_PROCESO

    def avanzar(self, minutos: int):
        # max() evita que el tiempo restante quede negativo
        self._minutos_restantes = max(0, self._minutos_restantes - minutos)

    def finalizar_lavado(self):
        self._minutos_restantes = 0
        self._estado = EstadoServicio.FINALIZADO
