from menu_console import MenuConsole


# 1. Paradigma POO: punto de entrada del programa
# 4. Métodos: main() es la función que se ejecuta al iniciar el programa
def main():
    menu = MenuConsole()  # Creación de un objeto (instancia)
    menu.iniciar()        # Llamado a un método del objeto


if __name__ == "__main__":
    main()
