from vehiculo import Vehiculo


# 7. Herencia: Auto EXTIENDE (hereda de) Vehiculo, reutilizando sus atributos y métodos
class Auto(Vehiculo):
    def __init__(self, patente: str, marca: str, modelo: str, cantidad_puertas: int):
        # 7. Herencia: "super()" llama al constructor de la clase padre (Vehiculo)
        super().__init__(patente, marca, modelo)
        self._cantidad_puertas = cantidad_puertas  # 2. Tipo de dato int

    @property
    def cantidad_puertas(self) -> int:
        return self._cantidad_puertas
