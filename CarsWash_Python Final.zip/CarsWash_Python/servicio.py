from abc import ABC, abstractmethod


# 8. Clases abstractas: no se puede instanciar directamente (Servicio() lanza TypeError)
# 5. Abstracción: define lo común a todos los servicios (nombre, precio y duración)
class Servicio(ABC):
    def __init__(self, nombre: str, precio_base: float, duracion_minutos: int):
        self._nombre = nombre                      # 6. Encapsulamiento: atributo "privado"
        self._precio_base = precio_base            # 2. Tipo de dato float | _ simple = "protegido" (para subclases)
        self._duracion_minutos = duracion_minutos  # 2. Tipo de dato int: cuánto demora el lavado

    @property
    def nombre(self) -> str:
        return self._nombre

    @property
    def duracion_minutos(self) -> int:
        return self._duracion_minutos

    # 8. Método abstracto: no tiene cuerpo aquí, cada subclase DEBE implementarlo
    # 10. Polimorfismo: cada tipo de lavado calculará su precio de forma distinta
    @abstractmethod
    def calcular_precio(self) -> float:
        pass
