import tkinter as tk
from tkinter import ttk, messagebox

from auto import Auto
from cliente import Cliente
from servicio import Servicio
from lavado_basico import LavadoBasico
from lavado_premium import LavadoPremium
from pagable import Pagable
from pago_efectivo import PagoEfectivo
from pago_tarjeta import PagoTarjeta
from carwash_controller import CarwashController
from cola_lavado import ColaLavado
from estado_servicio import EstadoServicio


# Reutiliza las mismas clases del proyecto:
# Cliente, Auto, Servicio, Pagable, CarwashController y ColaLavado.
class CarwashGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Sistema de Gestion Carwash")
        self.geometry("720x520")
        self.minsize(640, 480)

        self._controller = CarwashController()
        self._cola = ColaLavado()
        self._clientes: dict[str, Cliente] = {}

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=8, pady=8)

        self._tab_registro = ttk.Frame(notebook, padding=12)
        self._tab_servicio = ttk.Frame(notebook, padding=12)
        self._tab_estado = ttk.Frame(notebook, padding=12)
        notebook.add(self._tab_registro, text="1. Registro")
        notebook.add(self._tab_servicio, text="2. Servicio y pago")
        notebook.add(self._tab_estado, text="3. Estado")

        self._construir_registro()
        self._construir_servicio()
        self._construir_estado()
        self._refrescar()

    # ------------------------------------------------------------------
    # PESTAÑA 1: CLIENTE + AUTO
    # ------------------------------------------------------------------
    def _construir_registro(self):
        f = self._tab_registro

        caja_cliente = ttk.LabelFrame(f, text="Paso 1: Cliente", padding=10)
        caja_cliente.pack(fill="x", pady=(0, 10))
        self._var_nombre = tk.StringVar()
        self._var_rut = tk.StringVar()
        self._fila(caja_cliente, "Nombre:", self._var_nombre, 0)
        self._fila(caja_cliente, "RUT:", self._var_rut, 1)
        ttk.Button(caja_cliente, text="Registrar cliente",
                   command=self._registrar_cliente).grid(row=2, column=1, sticky="e", pady=(6, 0))

        caja_auto = ttk.LabelFrame(f, text="Paso 2: Auto del cliente", padding=10)
        caja_auto.pack(fill="x")
        ttk.Label(caja_auto, text="Cliente:").grid(row=0, column=0, sticky="w", pady=3)
        self._cmb_cliente_auto = ttk.Combobox(caja_auto, state="readonly", width=34)
        self._cmb_cliente_auto.grid(row=0, column=1, sticky="we", pady=3)
        self._var_patente = tk.StringVar()
        self._var_marca = tk.StringVar()
        self._var_modelo = tk.StringVar()
        self._var_puertas = tk.StringVar(value="4")
        self._fila(caja_auto, "Patente:", self._var_patente, 1)
        self._fila(caja_auto, "Marca:", self._var_marca, 2)
        self._fila(caja_auto, "Modelo:", self._var_modelo, 3)
        self._fila(caja_auto, "Puertas:", self._var_puertas, 4)
        ttk.Button(caja_auto, text="Registrar auto",
                   command=self._registrar_auto).grid(row=5, column=1, sticky="e", pady=(6, 0))
        caja_auto.columnconfigure(1, weight=1)

    @staticmethod
    def _fila(padre, texto, variable, fila):
        ttk.Label(padre, text=texto).grid(row=fila, column=0, sticky="w", pady=3, padx=(0, 8))
        ttk.Entry(padre, textvariable=variable, width=36).grid(row=fila, column=1, sticky="we", pady=3)
        padre.columnconfigure(1, weight=1)

    def _registrar_cliente(self):
        nombre = self._var_nombre.get().strip()
        rut = self._var_rut.get().strip()
        if not nombre or not rut:
            messagebox.showwarning("Datos incompletos", "Ingrese nombre y RUT.")
            return
        if rut in self._clientes:
            messagebox.showwarning("Duplicado", "Ese RUT ya esta registrado.")
            return
        self._clientes[rut] = Cliente(nombre, rut)
        self._var_nombre.set("")
        self._var_rut.set("")
        self._refrescar()
        messagebox.showinfo("Listo", "Cliente registrado. Ahora registre su auto.")

    def _registrar_auto(self):
        cliente = self._cliente_seleccionado(self._cmb_cliente_auto)
        if cliente is None:
            messagebox.showwarning("Falta cliente", "Seleccione un cliente.")
            return
        if cliente.tiene_vehiculo() and not cliente.vehiculo.puede_contratar_servicio():
            messagebox.showwarning("Auto en servicio",
                                   "El auto de este cliente esta en servicio, no se puede reemplazar.")
            return
        patente = self._var_patente.get().strip()
        marca = self._var_marca.get().strip()
        modelo = self._var_modelo.get().strip()
        if not patente or not marca or not modelo:
            messagebox.showwarning("Datos incompletos", "Complete patente, marca y modelo.")
            return
        try:
            puertas = int(self._var_puertas.get())
        except ValueError:
            messagebox.showwarning("Dato invalido", "Las puertas deben ser un numero entero.")
            return
        cliente.registrar_vehiculo(Auto(patente, marca, modelo, puertas))
        for v in (self._var_patente, self._var_marca, self._var_modelo):
            v.set("")
        self._var_puertas.set("4")
        self._refrescar()
        messagebox.showinfo("Listo", "Auto registrado para " + cliente.nombre + ".")

    # ------------------------------------------------------------------
    # PESTAÑA 2: SERVICIO + PAGO
    # ------------------------------------------------------------------
    def _construir_servicio(self):
        f = self._tab_servicio

        ttk.Label(f, text="Cliente:").grid(row=0, column=0, sticky="w", pady=4)
        self._cmb_cliente_serv = ttk.Combobox(f, state="readonly", width=40)
        self._cmb_cliente_serv.grid(row=0, column=1, sticky="we", pady=4)

        caja_serv = ttk.LabelFrame(f, text="Servicio", padding=10)
        caja_serv.grid(row=1, column=0, columnspan=2, sticky="we", pady=8)
        self._var_servicio = tk.IntVar(value=1)
        ttk.Radiobutton(caja_serv, text="Lavado Basico - $8.000 - 20 min",
                        variable=self._var_servicio, value=1).pack(anchor="w")
        ttk.Radiobutton(caja_serv, text="Lavado Premium (encerado) - $15.000 + IVA - 40 min",
                        variable=self._var_servicio, value=2).pack(anchor="w")

        caja_pago = ttk.LabelFrame(f, text="Medio de pago", padding=10)
        caja_pago.grid(row=2, column=0, columnspan=2, sticky="we", pady=8)
        self._var_pago = tk.IntVar(value=1)
        ttk.Radiobutton(caja_pago, text="Efectivo", variable=self._var_pago, value=1,
                        command=self._actualizar_campo_tarjeta).grid(row=0, column=0, sticky="w")
        ttk.Radiobutton(caja_pago, text="Tarjeta", variable=self._var_pago, value=2,
                        command=self._actualizar_campo_tarjeta).grid(row=0, column=1, sticky="w", padx=20)
        ttk.Label(caja_pago, text="N° tarjeta:").grid(row=1, column=0, sticky="w", pady=(8, 0))
        self._var_tarjeta = tk.StringVar()
        self._ent_tarjeta = ttk.Entry(caja_pago, textvariable=self._var_tarjeta, width=28, state="disabled")
        self._ent_tarjeta.grid(row=1, column=1, sticky="w", pady=(8, 0), padx=20)

        ttk.Button(f, text="Pagar y contratar servicio",
                   command=self._contratar_servicio).grid(row=3, column=1, sticky="e", pady=10)
        f.columnconfigure(1, weight=1)

    def _actualizar_campo_tarjeta(self):
        self._ent_tarjeta.configure(state="normal" if self._var_pago.get() == 2 else "disabled")

    def _contratar_servicio(self):
        cliente = self._cliente_seleccionado(self._cmb_cliente_serv)
        if cliente is None:
            messagebox.showwarning("Falta cliente", "Seleccione un cliente.")
            return
        if not cliente.tiene_vehiculo():
            messagebox.showwarning("Sin auto", "Este cliente no tiene auto. Registrelo primero.")
            return
        if not cliente.vehiculo.puede_contratar_servicio():
            messagebox.showwarning("Servicio activo", "El auto " + cliente.vehiculo.patente
                                   + " ya tiene un servicio activo ("
                                   + cliente.vehiculo.estado.value + ").")
            return

        # 8. Clases abstractas / 9. Interfaces: se usan los tipos abstractos
        servicio: Servicio = LavadoBasico() if self._var_servicio.get() == 1 else LavadoPremium()
        medio_pago: Pagable
        if self._var_pago.get() == 1:
            medio_pago = PagoEfectivo()
        else:
            numero = self._var_tarjeta.get().strip()
            if not numero:
                messagebox.showwarning("Falta tarjeta", "Ingrese el numero de tarjeta.")
                return
            medio_pago = PagoTarjeta(numero)

        total = servicio.calcular_precio()
        if not messagebox.askyesno("Confirmar pago",
                                   servicio.nombre + "\nTotal a pagar: $" + f"{total:,.0f}".replace(",", ".")
                                   + "\n\nConfirmar?"):
            return

        pago_ok = self._controller.procesar_atencion(cliente, servicio, medio_pago)
        if not pago_ok:
            messagebox.showerror("Pago rechazado", "Error al procesar el pago.")
            return

        espera = self._cola.tiempo_espera_nuevo_auto()  # se calcula ANTES de agregarlo
        cliente.vehiculo.asignar_servicio(servicio)
        self._cola.agregar(cliente)
        self._var_tarjeta.set("")
        self._refrescar()
        if espera == 0:
            messagebox.showinfo("Pago exitoso", "Su auto pasa a lavado de inmediato.")
        else:
            messagebox.showinfo("Pago exitoso",
                                "Su auto quedo en espera. Tiempo estimado para iniciar: " + str(espera) + " min")

    # ------------------------------------------------------------------
    # PESTAÑA 3: ESTADO
    # ------------------------------------------------------------------
    def _construir_estado(self):
        f = self._tab_estado

        self._lbl_puesto = ttk.Label(f, text="", font=("TkDefaultFont", 11, "bold"))
        self._lbl_puesto.pack(anchor="w")
        self._lbl_espera = ttk.Label(f, text="")
        self._lbl_espera.pack(anchor="w", pady=(0, 8))

        columnas = ("cliente", "patente", "vehiculo", "servicio", "estado", "restante")
        self._tabla = ttk.Treeview(f, columns=columnas, show="headings", height=10)
        encabezados = {"cliente": "Cliente", "patente": "Patente", "vehiculo": "Vehiculo",
                       "servicio": "Servicio", "estado": "Estado", "restante": "Min. restantes"}
        anchos = {"cliente": 110, "patente": 80, "vehiculo": 120, "servicio": 150,
                  "estado": 130, "restante": 90}
        for c in columnas:
            self._tabla.heading(c, text=encabezados[c])
            self._tabla.column(c, width=anchos[c], anchor="w")
        self._tabla.pack(fill="both", expand=True)

        barra = ttk.Frame(f)
        barra.pack(fill="x", pady=(10, 0))
        ttk.Label(barra, text="Avanzar tiempo (min):").pack(side="left")
        self._var_minutos = tk.StringVar(value="10")
        ttk.Spinbox(barra, from_=1, to=600, width=6, textvariable=self._var_minutos).pack(side="left", padx=6)
        ttk.Button(barra, text="Avanzar", command=self._avanzar_tiempo).pack(side="left")

    def _avanzar_tiempo(self):
        try:
            minutos = int(self._var_minutos.get())
        except ValueError:
            messagebox.showwarning("Dato invalido", "Debe ingresar un numero entero.")
            return
        if minutos <= 0:
            messagebox.showwarning("Dato invalido", "Los minutos deben ser mayores a 0.")
            return
        self._cola.avanzar_tiempo(minutos)
        self._refrescar()

    # ------------------------------------------------------------------
    # Utilidades
    # ------------------------------------------------------------------
    @staticmethod
    def _etiqueta(cliente: Cliente) -> str:
        return cliente.nombre + " (" + cliente.rut + ")"

    def _cliente_seleccionado(self, combo: ttk.Combobox):
        indice = combo.current()
        if indice < 0:
            return None
        return list(self._clientes.values())[indice]

    def _refrescar(self):
        # Combos de clientes
        etiquetas = [self._etiqueta(c) for c in self._clientes.values()]
        for combo in (self._cmb_cliente_auto, self._cmb_cliente_serv):
            actual = combo.current()
            combo["values"] = etiquetas
            if 0 <= actual < len(etiquetas):
                combo.current(actual)

        # Panel de estado
        en_proceso = self._cola.en_proceso()
        if en_proceso is None:
            self._lbl_puesto.configure(text="Puesto de lavado: LIBRE")
        else:
            v = en_proceso.vehiculo
            self._lbl_puesto.configure(
                text="Puesto de lavado: OCUPADO - " + v.patente + " (" + en_proceso.nombre + ") - "
                     + str(v.minutos_restantes) + " min restantes")
        self._lbl_espera.configure(
            text="Autos en espera: " + str(len(self._cola.en_espera()))
                 + "   |   Espera estimada para un auto nuevo: "
                 + str(self._cola.tiempo_espera_nuevo_auto()) + " min")

        # Tabla de clientes / autos
        self._tabla.delete(*self._tabla.get_children())
        for cliente in self._clientes.values():
            if cliente.tiene_vehiculo():
                v = cliente.vehiculo
                servicio = v.servicio.nombre if v.servicio is not None else "-"
                restante = str(v.minutos_restantes) if v.estado in (
                    EstadoServicio.EN_ESPERA, EstadoServicio.EN_PROCESO) else "-"
                self._tabla.insert("", "end", values=(
                    cliente.nombre, v.patente, v.marca + " " + v.modelo,
                    servicio, v.estado.value, restante))
            else:
                self._tabla.insert("", "end", values=(
                    cliente.nombre, "-", "sin auto registrado", "-", "-", "-"))


def main():
    CarwashGUI().mainloop()


if __name__ == "__main__":
    main()
