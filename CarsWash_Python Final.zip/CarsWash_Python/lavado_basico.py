from servicio import Servicio


# 7. Herencia: hereda de la clase abstracta Servicio
class LavadoBasico(Servicio):
    def __init__(self):
        # 7. Herencia: llama al constructor del padre (Servicio) con nombre, precio y duración (20 min)
        super().__init__("Lavado Básico", 8000.0, 20)

    # 10. Polimorfismo: se sobreescribe (override) el método abstracto de Servicio
    def calcular_precio(self) -> float:
        return self._precio_base  # Retorno simple, sin recargos
