from cliente import Cliente
from estado_servicio import EstadoServicio


# 1. Paradigma POO: administra la fila de autos del carwash
# (hay un solo puesto de lavado: un auto a la vez, los demás esperan)
# La cola guarda CLIENTES; el estado se lee y se modifica en el VEHICULO de cada cliente.
class ColaLavado:
    def __init__(self):
        self._clientes: list[Cliente] = []  # 3. Estructura de datos: lista de objetos

    @staticmethod
    def _descripcion(cliente: Cliente) -> str:
        return cliente.vehiculo.patente + " (" + cliente.nombre + ")"

    # --- Consultas -------------------------------------------------------
    def en_proceso(self):
        # 3. Estructura de control: recorrido de la lista buscando el auto que se está lavando
        for cliente in self._clientes:
            if cliente.vehiculo.estado == EstadoServicio.EN_PROCESO:
                return cliente
        return None

    def en_espera(self) -> list:
        return [c for c in self._clientes if c.vehiculo.estado == EstadoServicio.EN_ESPERA]

    def finalizados(self) -> list:
        return [c for c in self._clientes if c.vehiculo.estado == EstadoServicio.FINALIZADO]

    def tiempo_espera_nuevo_auto(self) -> int:
        """Minutos que deberá esperar un auto que llegue ahora (antes de que parta su lavado)."""
        total = 0
        actual = self.en_proceso()
        if actual is not None:
            total += actual.vehiculo.minutos_restantes
        for cliente in self.en_espera():
            total += cliente.vehiculo.servicio.duracion_minutos
        return total

    def tiempo_espera(self, objetivo: Cliente) -> int:
        """Minutos que faltan para que un auto en espera comience su lavado."""
        total = 0
        actual = self.en_proceso()
        if actual is not None:
            total += actual.vehiculo.minutos_restantes
        for cliente in self.en_espera():
            if cliente is objetivo:
                return total
            total += cliente.vehiculo.servicio.duracion_minutos
        return total

    # --- Acciones --------------------------------------------------------
    def agregar(self, cliente: Cliente):
        # Un auto que vuelve a lavarse no se duplica en la lista
        if cliente not in self._clientes:
            self._clientes.append(cliente)
        self._iniciar_siguiente_si_hay_puesto_libre()

    def _iniciar_siguiente_si_hay_puesto_libre(self):
        if self.en_proceso() is None:
            esperando = self.en_espera()
            if esperando:
                siguiente = esperando[0]
                siguiente.vehiculo.iniciar_lavado()
                print(">> Comienza el lavado de: " + self._descripcion(siguiente))

    def avanzar_tiempo(self, minutos: int):
        """Simula el paso del tiempo; si un lavado termina, entra el siguiente auto."""
        # 3. Estructura de control: while, se repite hasta gastar todos los minutos
        while minutos > 0 and self.en_proceso() is not None:
            actual = self.en_proceso()
            usados = min(minutos, actual.vehiculo.minutos_restantes)
            actual.vehiculo.avanzar(usados)
            minutos -= usados
            if actual.vehiculo.minutos_restantes == 0:
                actual.vehiculo.finalizar_lavado()
                print(">> Lavado FINALIZADO: " + self._descripcion(actual))
                self._iniciar_siguiente_si_hay_puesto_libre()

    def mostrar_estado(self):
        print("\n========== ESTADO DEL CARWASH ==========")
        actual = self.en_proceso()
        if actual is None:
            print("Puesto de lavado: LIBRE")
        else:
            print("Puesto de lavado: OCUPADO")
            print("  Auto en proceso : " + self._descripcion(actual))
            print("  Servicio        : " + actual.vehiculo.servicio.nombre)
            print("  Tiempo restante : " + str(actual.vehiculo.minutos_restantes) + " min")

        esperando = self.en_espera()
        print("Autos en espera: " + str(len(esperando)))
        for posicion, cliente in enumerate(esperando, start=1):
            print("  " + str(posicion) + ". " + self._descripcion(cliente)
                  + " | " + cliente.vehiculo.servicio.nombre
                  + " | inicia en ~" + str(self.tiempo_espera(cliente)) + " min")

        terminados = self.finalizados()
        print("Autos finalizados: " + str(len(terminados)))
        for cliente in terminados:
            print("  - " + self._descripcion(cliente) + " | " + cliente.vehiculo.servicio.nombre)
        print("Espera estimada para un auto nuevo: " + str(self.tiempo_espera_nuevo_auto()) + " min")
        print("========================================")
