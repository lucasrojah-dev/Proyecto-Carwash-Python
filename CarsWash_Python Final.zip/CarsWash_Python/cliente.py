from vehiculo import Vehiculo


# 1. Paradigma POO: el Cliente es el PRIMER paso del sistema y es "dueño" del auto
# 5. Clases y abstracción: solo se guarda lo relevante del cliente para el sistema
class Cliente:
    def __init__(self, nombre: str, rut: str):
        # 6. Encapsulamiento: atributos "privados"
        self._nombre = nombre  # 2. Tipo de dato str
        self._rut = rut        # 2. Tipo de dato str
        self._vehiculo = None  # 1. Composición: se asigna en el SEGUNDO paso (registrar auto)

    # 6. Encapsulamiento: properties para acceder a los atributos privados
    @property
    def nombre(self) -> str:
        return self._nombre

    @property
    def rut(self) -> str:
        return self._rut

    @property
    def vehiculo(self):
        return self._vehiculo

    # 4. Métodos: el cliente registra su vehículo (un Cliente "tiene un" Vehiculo)
    def registrar_vehiculo(self, vehiculo: Vehiculo):
        self._vehiculo = vehiculo

    def tiene_vehiculo(self) -> bool:
        return self._vehiculo is not None
