from cliente import Cliente
from servicio import Servicio
from pagable import Pagable


# 1. Paradigma POO: esta clase ORQUESTA la interacción entre distintos objetos
class CarwashController:

    # 4. Métodos: acción que realiza el sistema, recibe distintos objetos como parámetros
    # 10. Polimorfismo: el parámetro "medio_pago" puede ser PagoEfectivo o PagoTarjeta
    # (no se sabe cuál hasta ejecutar el programa, pero el método funciona igual para ambos)
    def procesar_atencion(self, cliente: Cliente, servicio: Servicio, medio_pago: Pagable) -> bool:
        print("--- INICIANDO ATENCION DE CARWASH ---")
        print("Cliente: " + cliente.nombre)
        print("Vehiculo Patente: " + cliente.vehiculo.patente)
        print("Servicio seleccionado: " + servicio.nombre)

        # 10. Polimorfismo: "servicio" puede ser LavadoBasico o LavadoPremium,
        # pero calcular_precio() ejecuta la versión correspondiente a cada uno
        total = servicio.calcular_precio()  # 2. Tipo de dato float
        print("Monto total a cancelar: $" + str(total))

        # 10. Polimorfismo: pagar() ejecuta la lógica de PagoEfectivo o PagoTarjeta según corresponda
        exito_pago = medio_pago.pagar(total)  # 2. Tipo de dato bool

        # 3. Estructura de control: condicional if/else
        if exito_pago:
            print("Servicio realizado con exito!")
            return True  # Operador de retorno
        else:
            print("Error al procesar el pago.")
            return False
