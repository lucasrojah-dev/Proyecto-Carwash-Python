from auto import Auto
from cliente import Cliente
from servicio import Servicio
from lavado_basico import LavadoBasico
from lavado_premium import LavadoPremium
from pagable import Pagable
from pago_efectivo import PagoEfectivo
from pago_tarjeta import PagoTarjeta
from carwash_controller import CarwashController
from cola_lavado import ColaLavado


# 1. Paradigma POO: interfaz de usuario por consola
# Flujo conectado:  1) CLIENTE  ->  2) AUTO del cliente  ->  3) SERVICIO + PAGO  ->  4) ESTADO del auto
class MenuConsole:
    def __init__(self):
        # 1. Composición de objetos: el menú "tiene un" controlador, "una" cola y "unos" clientes
        self._controller = CarwashController()  # 6. Encapsulamiento: atributo "privado"
        self._cola = ColaLavado()
        self._clientes: dict[str, Cliente] = {}  # 3. Estructura de datos: diccionario rut -> Cliente

    # 4. Métodos: acción principal que inicia el flujo del programa
    def iniciar(self):
        print("=== SISTEMA DE GESTION CARWASH ===")
        salir = False
        # 3. Estructura de control: ciclo while, el menú se repite hasta elegir "Salir"
        while not salir:
            print("\n--- MENU PRINCIPAL ---")
            print("1. Registrar cliente")
            print("2. Registrar auto del cliente")
            print("3. Contratar servicio y pagar")
            print("4. Ver estado del carwash")
            print("5. Avanzar tiempo (simulacion)")
            print("6. Salir")
            opcion = input("Opcion: ").strip()

            if opcion == "1":
                self._registrar_cliente()
            elif opcion == "2":
                self._registrar_auto()
            elif opcion == "3":
                self._contratar_servicio()
            elif opcion == "4":
                self._ver_estado()
            elif opcion == "5":
                self._avanzar_tiempo()
            elif opcion == "6":
                salir = True
                print("Hasta luego!")
            else:
                print("Opcion no valida.")

    # --- PASO 1: CLIENTE ---------------------------------------------------
    def _registrar_cliente(self):
        nombre = input("Ingrese Nombre del Cliente: ")  # 2. Tipo de dato str
        rut = input("Ingrese RUT: ").strip()
        if rut in self._clientes:
            print("Ese RUT ya esta registrado.")
            return
        self._clientes[rut] = Cliente(nombre, rut)
        print("Cliente registrado. Ahora registre su auto (opcion 2).")

    def _buscar_cliente(self):
        rut = input("Ingrese RUT del cliente: ").strip()
        cliente = self._clientes.get(rut)
        if cliente is None:
            print("Cliente no encontrado. Primero debe registrarlo (opcion 1).")
        return cliente

    # --- PASO 2: AUTO del cliente -----------------------------------------
    def _registrar_auto(self):
        cliente = self._buscar_cliente()
        if cliente is None:
            return
        if cliente.tiene_vehiculo() and not cliente.vehiculo.puede_contratar_servicio():
            print("El auto de este cliente esta en servicio, no se puede reemplazar.")
            return
        patente = input("Ingrese Patente del Vehiculo: ")
        marca = input("Ingrese Marca: ")
        modelo = input("Ingrese Modelo: ")
        try:
            puertas = int(input("Cantidad de puertas: "))  # 2. Tipo de dato int
        except ValueError:
            print("Debe ingresar un numero entero.")
            return
        # 7. Herencia: se crea un objeto Auto (subclase) y el cliente lo guarda como Vehiculo
        cliente.registrar_vehiculo(Auto(patente, marca, modelo, puertas))
        print("Auto registrado para " + cliente.nombre + ". Estado: " + cliente.vehiculo.estado.value)

    # --- PASO 3: SERVICIO + PAGO -> aquí comienza el proceso de estado ---
    def _contratar_servicio(self):
        cliente = self._buscar_cliente()
        if cliente is None:
            return
        if not cliente.tiene_vehiculo():
            print("Este cliente no tiene auto. Primero registrelo (opcion 2).")
            return
        if not cliente.vehiculo.puede_contratar_servicio():
            print("El auto " + cliente.vehiculo.patente + " ya tiene un servicio activo ("
                  + cliente.vehiculo.estado.value + ").")
            return

        # Selección de Servicio
        print("\nSeleccione el Servicio:")
        print("1. Lavado Basico ($8,000) - 20 min")
        print("2. Lavado Premium ($15,000 + IVA) - 40 min")
        try:
            opc_servicio = int(input())
            print("\nSeleccione Medio de Pago:")
            print("1. Efectivo")
            print("2. Tarjeta")
            opc_pago = int(input())
        except ValueError:
            print("Debe ingresar un numero entero.")
            return

        # 8. Clases abstractas: "servicio" es del tipo abstracto Servicio,
        # pero se instancia como una de sus subclases concretas
        servicio: Servicio
        if opc_servicio == 1:  # Operador de comparación "=="
            servicio = LavadoBasico()
        else:
            servicio = LavadoPremium()

        # 9. Interfaces: "medio_pago" es del tipo Pagable,
        # pero se instancia como PagoEfectivo o PagoTarjeta
        medio_pago: Pagable
        if opc_pago == 1:
            medio_pago = PagoEfectivo()
        else:
            num_tarjeta = input("Ingrese numero de tarjeta: ")
            medio_pago = PagoTarjeta(num_tarjeta)

        # 4. Ejecución del Controlador: se delega el cobro al controlador
        pago_ok = self._controller.procesar_atencion(cliente, servicio, medio_pago)

        # Solo si el pago fue exitoso el AUTO cambia de estado y entra a la fila
        if pago_ok:
            espera = self._cola.tiempo_espera_nuevo_auto()  # se calcula ANTES de agregarlo
            cliente.vehiculo.asignar_servicio(servicio)     # estado del auto: EN_ESPERA
            self._cola.agregar(cliente)                     # si el puesto esta libre, pasa a EN_PROCESO
            if espera == 0:
                print("Su auto pasa a lavado de inmediato.")
            else:
                print("Su auto quedo en espera. Tiempo estimado para iniciar: " + str(espera) + " min")

    # --- PASO 4: ESTADO del auto -------------------------------------------
    def _ver_estado(self):
        self._cola.mostrar_estado()
        print("\nCLIENTES REGISTRADOS:")
        if not self._clientes:
            print("  (ninguno)")
        for cliente in self._clientes.values():
            if cliente.tiene_vehiculo():
                v = cliente.vehiculo
                print("  " + cliente.nombre + " (" + cliente.rut + ") -> " + v.marca + " " + v.modelo
                      + " [" + v.patente + "] -> " + v.estado.value)
            else:
                print("  " + cliente.nombre + " (" + cliente.rut + ") -> sin auto registrado")

    def _avanzar_tiempo(self):
        try:
            minutos = int(input("Cuantos minutos desea avanzar?: "))
        except ValueError:
            print("Debe ingresar un numero entero.")
            return
        if minutos <= 0:
            print("Los minutos deben ser mayores a 0.")
            return
        self._cola.avanzar_tiempo(minutos)
        self._ver_estado()
