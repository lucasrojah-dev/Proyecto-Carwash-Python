from servicio import Servicio


# 7. Herencia: hereda de la clase abstracta Servicio
class LavadoPremium(Servicio):
    def __init__(self):
        # Duración: 40 minutos (incluye encerado)
        super().__init__("Lavado Premium (Incluye encerado)", 15000.0, 40)

    # 10. Polimorfismo: mismo método "calcular_precio()" pero con un comportamiento diferente
    def calcular_precio(self) -> float:
        return self._precio_base * 1.19  # Operador "*" (multiplicación) para aplicar IVA
